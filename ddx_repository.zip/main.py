# FastAPI application entrypoint
